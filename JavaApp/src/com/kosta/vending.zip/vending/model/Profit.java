package com.kosta.vending.model;

public class Profit {
	
	private int total;

	
	public Profit(){
		
	}
	
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}

	

}
