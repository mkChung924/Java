package com.kosta.vending.view;

import java.awt.Dimension;

import javax.swing.JLabel;

public class RamenDrop implements Runnable{
	
	Dimension windowSize;
	JLabel jlabel;
	int x,y;
	public boolean threadRunning;
	
	public void run(){
	
	threadRunning = true;
	//System.out.println(Thread.currentThread().getState()+ "1");
	
	try {
		for(int i = y; i <= windowSize.getHeight()-130; i+=5){
			Thread.sleep(3);
			jlabel.setLocation(x, i);

			if(i >= windowSize.getHeight()-130){
				
				return;
			}
		}
		
	} catch (InterruptedException e) {
			e.printStackTrace();
			
	} finally{
		try {
			Thread.sleep(300);
			jlabel.setLocation(x,y);
			
			//System.out.println(Thread.currentThread().getState()+ "2");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
	//System.out.println(Thread.currentThread().getState() + "3");
	threadRunning = false;
	//System.out.println(threadRunning);
	//setItDisable(accum);
}
	
	public void getDimension(Dimension dimension){
		
		windowSize = dimension;
	}
	
	public void getXY(JLabel jlabel){
		x = jlabel.getX();
		y = jlabel.getY();
		//System.out.println("x: " + x + ", y: " + y);
		this.jlabel = jlabel;
	}

}
