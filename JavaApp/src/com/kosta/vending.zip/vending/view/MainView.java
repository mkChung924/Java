package com.kosta.vending.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class MainView extends JFrame{

	public JLabel glass, logo, wonIcon, noChange, returnMoney, coinEnter, exit, getMoney, backGround,returnedCoins;
	JLabel price, won;
	public JTextField tf, output;
	public JButton bill, coin5, coin1, moneyBack, admin, billEnter2;
	
	public JLabel[] labels, labels_1;
	int numberOfIndex = 8;
	
	public MainView() {
		
		setTitle("������ �Ŷ�� ���Ǳ�");
		
		labels = new JLabel[numberOfIndex];
		for(int i = 0; i < numberOfIndex; i++){
			String labelText = "" + (i + 1);
		    labels[i] = new JLabel("<html><font size = 5>"+labelText+"</font><html>", JLabel.CENTER);
		    add(labels[i]);
		}
	    labels[0].setBounds(30,25,125,125);
	    labels[1].setBounds(200,25,125,125);
	    labels[2].setBounds(30,180,125,125);
	    labels[3].setBounds(200,180,125,125);
	    labels[4].setBounds(30,330,125,125);
	    labels[5].setBounds(200,330,125,125);
	    labels[6].setBounds(30,480,125,125);
	    labels[7].setBounds(200,480,125,125);
	    
	    labels_1 = new JLabel[numberOfIndex];
		for(int i = 0; i < numberOfIndex; i++){
			String labelText = "" + (i + 1);
		    labels_1[i] = new JLabel("<html><font size = 6>"+labelText+"</font><html>", JLabel.CENTER);
		    labels_1[i].setFont(new Font("Courier", Font.BOLD,14));
		    add(labels_1[i]);
		}
		labels_1[0].setBounds(30,145,130,30);
		labels_1[1].setBounds(200,145,130,30);
		labels_1[2].setBounds(30,300,130,30);
		labels_1[3].setBounds(200,300,130,30);
		labels_1[4].setBounds(30,455,130,30);
		labels_1[5].setBounds(200,455,130,30);
		labels_1[6].setBounds(30,600,130,30);
		labels_1[7].setBounds(200,600,130,30);

		tf = new JTextField("0");
		bill = new JButton(new ImageIcon(new ImageIcon("image/vendingmachine/money1000.png").getImage().getScaledInstance(120, 80, Image.SCALE_DEFAULT)));
		coin5 = new JButton(new ImageIcon(new ImageIcon("image/vendingmachine/money500.png").getImage().getScaledInstance(80, 80, Image.SCALE_DEFAULT)));
		coin1 = new JButton(new ImageIcon(new ImageIcon("image/vendingmachine/money100.png").getImage().getScaledInstance(70, 70, Image.SCALE_DEFAULT)));
		admin = new JButton(new ImageIcon(new ImageIcon("image/vendingmachine/admin.png").getImage().getScaledInstance(120, 40, Image.SCALE_DEFAULT)));
				
		glass = new JLabel();
		returnMoney = new JLabel(new ImageIcon(new ImageIcon("image/vendingmachine/returnMoney.png")
				.getImage().getScaledInstance(80, 80, Image.SCALE_DEFAULT)));
		price = new JLabel("�ݾ�");
		won = new JLabel("��");
		backGround = new JLabel();

		logo = new JLabel(new ImageIcon(new ImageIcon("image/vendingmachine/logo_sq.png").getImage().getScaledInstance(200, 150, Image.SCALE_DEFAULT)));
		wonIcon = new JLabel("<html><font size = 6 color = red>W</font><html>", JLabel.CENTER);
		noChange = new JLabel(new ImageIcon(new ImageIcon("image/vendingmachine/noMoney_ro.png").getImage().getScaledInstance(130, 45, Image.SCALE_DEFAULT)));
		billEnter2 = new JButton(new ImageIcon(new ImageIcon("image/vendingmachine/putMoney.png").getImage().getScaledInstance(160, 60, Image.SCALE_DEFAULT)));
		coinEnter = new JLabel(new ImageIcon(new ImageIcon("image/vendingmachine/putCoin.png").getImage().getScaledInstance(75, 75, Image.SCALE_DEFAULT)));
		exit = new JLabel(new ImageIcon(new ImageIcon("image/vendingmachine/productBg.png").getImage().getScaledInstance(680, 150, Image.SCALE_DEFAULT)));
		getMoney = new JLabel(new ImageIcon(new ImageIcon("image/vendingmachine/returnMoneyBg.png").getImage().getScaledInstance(90, 65, Image.SCALE_DEFAULT)));
		returnedCoins = new JLabel(new ImageIcon(new ImageIcon("image/vendingmachine/changes.png").getImage().getScaledInstance(80, 35, Image.SCALE_DEFAULT)));
		
		//�Ӽ�����
		setLayout(null);
		glass.setBounds(10,10,350,620);
		glass.setBackground(new Color(230,253,255));
		glass.setOpaque(true);
		
		backGround.setBounds(0,0,710,850);
		backGround.setBackground(new Color(255,255,108));
		backGround.setOpaque(true);
		
		returnMoney.setBounds(570,410, 80,80);
		billEnter2.setBounds(375,400,155,60);
		coinEnter.setBounds(570, 320, 75, 75);
		billEnter2.setRolloverEnabled(true);
		billEnter2.setRolloverIcon(new ImageIcon(new ImageIcon("image/vendingmachine/putMoney_ro.png").getImage().getScaledInstance(160, 60, Image.SCALE_DEFAULT)));
		
		tf.setBounds(380,330,140,55);
		tf.setHorizontalAlignment(JTextField.RIGHT);
		Font font = new Font("Courier", Font.BOLD,30);
		tf.setFont(font);
		tf.setEditable(false);
		tf.setForeground(Color.white);
		tf.setBackground(Color.black);
		
		admin.setBounds(575,10,120,40);
		bill.setBounds(390, 470, 120, 80);
		coin5.setBounds(510, 180, 80, 80);
		coin1.setBounds(605, 185, 70, 70);
		
		admin.setRolloverEnabled(true);
		bill.setRolloverEnabled(true);	
		coin5.setRolloverEnabled(true);
		coin1.setRolloverEnabled(true);
		bill.setVisible(false);
		coin5.setVisible(false);
		coin1.setVisible(false);
		
		admin.setRolloverIcon(new ImageIcon(new ImageIcon("image/vendingmachine/admin_ro.png").getImage().getScaledInstance(120, 40, Image.SCALE_DEFAULT)));
		bill.setRolloverIcon(new ImageIcon(new ImageIcon("image/vendingmachine/money1000_ro.png").getImage().getScaledInstance(120, 80, Image.SCALE_DEFAULT)));
		coin5.setRolloverIcon(new ImageIcon(new ImageIcon("image/vendingmachine/money500_ro.png").getImage().getScaledInstance(80, 80, Image.SCALE_DEFAULT)));
		coin1.setRolloverIcon(new ImageIcon(new ImageIcon("image/vendingmachine/money100_ro.png").getImage().getScaledInstance(70, 70, Image.SCALE_DEFAULT)));
		
		logo.setBounds(370, 10, 200, 150);
		wonIcon.setBounds(380,330,50,50);
		noChange.setBounds(385,285, 130,45);
		exit.setBounds(10, 635, 680, 150);
		getMoney.setBounds(565, 560, 90, 65);
		returnedCoins.setBounds(570, 585, 80, 35);
		returnedCoins.setVisible(false);
		
		
		add(wonIcon);
		add(tf);
		add(glass);
		add(exit);
		add(bill);
		add(coin5);
		add(coin1);
		add(logo);
		add(noChange);
		add(returnMoney);
		add(billEnter2);
		add(coinEnter);
		add(admin);
		add(returnedCoins);
		add(getMoney);
		add(backGround);
		
		
		setBounds(300,0,700,810);
		setVisible(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		
	}
	
	
}
