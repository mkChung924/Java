package com.kosta.vending.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AdminView extends JFrame{

	JPanel p1, p2, p3;
	JLabel pName, pPrice, pCount, fiveCount, oneCount, myProfit;
	public JTextField tf1, tf1p, tf1c, tf2, tf2p, tf2c, tf3, tf3p, tf3c, 
	tf4, tf4p, tf4c, tf5, tf5p, tf5c, tf6, tf6p, tf6c, tf7, tf7p, tf7c, tf8, tf8p, tf8c,
	tf_five, tf_one, tf_profit;
	public JButton submit, cancel, getProfit;
	public JComboBox<String> ramen1,ramen2,ramen3,ramen4,ramen5,ramen6,ramen7,ramen8,
						price1, price2, price3, price4, price5, price6, price7, price8;
	
	public AdminView() {
		
		String ramens[]={"�Ŷ��", "�����", "��¡��«��", "������", "��������", "��ġ��", "¥�İ�Ƽ", "�ʱ���"};
		String prices[]={"800","900","1000","1200","1500","1900"};
		
		p1 = new JPanel();
		p2 = new JPanel();
		p3 = new JPanel();
		pName = new JLabel("ǰ���", JLabel.CENTER);
		pPrice = new JLabel("����", JLabel.CENTER);
		pCount = new JLabel("����", JLabel.CENTER);
		fiveCount = new JLabel("500��", JLabel.CENTER);
		oneCount = new JLabel("100��", JLabel.CENTER);
		myProfit = new JLabel("����", JLabel.CENTER);
		ramen1 = new JComboBox<String>(ramens);
		ramen2 = new JComboBox<String>(ramens);
		ramen3 = new JComboBox<String>(ramens);
		ramen4 = new JComboBox<String>(ramens);
		ramen5 = new JComboBox<String>(ramens);
		ramen6 = new JComboBox<String>(ramens);
		ramen7 = new JComboBox<String>(ramens);
		ramen8 = new JComboBox<String>(ramens);
		price1 = new JComboBox<>(prices);
		price2 = new JComboBox<>(prices);
		price3 = new JComboBox<>(prices);
		price4 = new JComboBox<>(prices);
		price5 = new JComboBox<>(prices);
		price6 = new JComboBox<>(prices);
		price7 = new JComboBox<>(prices);
		price8 = new JComboBox<>(prices);
		
		
		tf1 = new JTextField(4);
		tf1p = new JTextField(4);
		tf1c = new JTextField(4);
		tf2 = new JTextField(4);
		tf2p = new JTextField(4);
		tf2c = new JTextField(4);
		tf3 = new JTextField(4);
		tf3p = new JTextField(4);
		tf3c = new JTextField(4);
		tf4 = new JTextField(4);
		tf4p = new JTextField(4);
		tf4c = new JTextField(4);
		tf5 = new JTextField(4);
		tf5p = new JTextField(4);
		tf5c = new JTextField(4);
		tf6 = new JTextField(4);
		tf6p = new JTextField(4);
		tf6c = new JTextField(4);
		tf7 = new JTextField(4);
		tf7p = new JTextField(4);
		tf7c = new JTextField(4);
		tf8 = new JTextField(4);
		tf8p = new JTextField(4);
		tf8c = new JTextField(4);
		tf_five = new JTextField(4);
		tf_one = new JTextField(4);
		tf_profit = new JTextField("0",4);
		
		submit = new JButton("Ȯ��");
		cancel = new JButton("�ݱ�");
		getProfit = new JButton("���� ì���");
		
		setLayout(null);
		
		p1.setLayout(new GridLayout(9, 3));
		p1.setBounds(10,10,300,300);
		p1.add(pName);
		p1.add(pPrice);
		p1.add(pCount);
		p1.add(ramen1);
		p1.add(price1);
		p1.add(tf1c);
		p1.add(ramen2);
		p1.add(price2);
		p1.add(tf2c);
		p1.add(ramen3);
		p1.add(price3);
		p1.add(tf3c);
		p1.add(ramen4);
		p1.add(price4);
		p1.add(tf4c);
		p1.add(ramen5);
		p1.add(price5);
		p1.add(tf5c);
		p1.add(ramen6);
		p1.add(price6);
		p1.add(tf6c);
		p1.add(ramen7);
		p1.add(price7);
		p1.add(tf7c);
		p1.add(ramen8);
		p1.add(price8);
		p1.add(tf8c);
		
		ramen2.setSelectedItem("�����");
		ramen3.setSelectedItem("��ġ��");
		ramen4.setSelectedItem("��¡��«��");
		ramen5.setSelectedItem("������");
		ramen6.setSelectedItem("¥�İ�Ƽ");
		ramen7.setSelectedItem("�ʱ���");
		ramen8.setSelectedItem("��������");
		
		p2.setLayout(new GridLayout(3, 3,0,0));
		p2.setBounds(10, 310, 300, 65);
		
		p2.add(new JLabel());
		p2.add(new JLabel("�Ž��� ��", JLabel.CENTER));
		p2.add(myProfit);
		p2.add(fiveCount);
		p2.add(tf_five);
		p2.add(tf_profit);
		p2.add(oneCount);
		p2.add(tf_one);
		p2.add(getProfit);
		
		tf_one.setHorizontalAlignment(JTextField.CENTER);
		tf_five.setHorizontalAlignment(JTextField.CENTER);
		tf_profit.setHorizontalAlignment(JTextField.CENTER);
		tf_profit.setEditable(false);
		tf_profit.setEnabled(false);
		
		p3.setLayout(new FlowLayout());
		p3.setBounds(10, 390, 300, 100);
		p3.add(submit);
		p3.add(cancel);
		
		add(p1);
		add(p2);
		add(p3);
		
		setTitle("���Ǳ� ��ǰ �ʱ�ȭ");
		setBounds(500,200,320,460);
		setVisible(true);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		
	
	}

}
