package com.kosta.vending.model;

public class Profit {
	
	private int total;
	private int fiveback;
	private int oneback;
	
	public Profit(){
		
	}
	
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getFiveback() {
		return fiveback;
	}
	public void setFiveback(int fiveback) {
		this.fiveback = fiveback;
	}
	public int getOneback() {
		return oneback;
	}
	public void setOneback(int oneback) {
		this.oneback = oneback;
	}
	
	

}
