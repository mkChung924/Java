package com.kosta.vending.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AdminView extends JFrame{

	JPanel p1, p2, p3;
	JLabel pName, pPrice, pCount, fiveCount, oneCount;
	public JTextField tf1, tf1p, tf1c, tf2, tf2p, tf2c, tf3, tf3p, tf3c, 
	tf4, tf4p, tf4c, tf5, tf5p, tf5c, tf6, tf6p, tf6c, tf7, tf7p, tf7c, tf8, tf8p, tf8c,
	tf_five, tf_one;
	public JButton submit, cancel;
	
	public AdminView() {
		
		p1 = new JPanel();
		p2 = new JPanel();
		p3 = new JPanel();
		pName = new JLabel("ǰ���", JLabel.CENTER);
		pPrice = new JLabel("����", JLabel.CENTER);
		pCount = new JLabel("����", JLabel.CENTER);
		fiveCount = new JLabel("500��", JLabel.CENTER);
		oneCount = new JLabel("100��", JLabel.CENTER);
		
		tf1 = new JTextField(4);
		tf1p = new JTextField(4);
		tf1c = new JTextField(4);
		tf2 = new JTextField(4);
		tf2p = new JTextField(4);
		tf2c = new JTextField(4);
		tf3 = new JTextField(4);
		tf3p = new JTextField(4);
		tf3c = new JTextField(4);
		tf4 = new JTextField(4);
		tf4p = new JTextField(4);
		tf4c = new JTextField(4);
		tf5 = new JTextField(4);
		tf5p = new JTextField(4);
		tf5c = new JTextField(4);
		tf6 = new JTextField(4);
		tf6p = new JTextField(4);
		tf6c = new JTextField(4);
		tf7 = new JTextField(4);
		tf7p = new JTextField(4);
		tf7c = new JTextField(4);
		tf8 = new JTextField(4);
		tf8p = new JTextField(4);
		tf8c = new JTextField(4);
		tf_five = new JTextField(4);
		tf_one = new JTextField(4);
		
		submit = new JButton("Ȯ��");
		cancel = new JButton("�ʱ�ȭ");
		
		setLayout(null);
		
		p1.setLayout(new GridLayout(9, 3));
		p1.setBounds(10,10,300,300);
		p1.add(pName);
		p1.add(pPrice);
		p1.add(pCount);
		p1.add(tf1);
		p1.add(tf1p);
		p1.add(tf1c);
		p1.add(tf2);
		p1.add(tf2p);
		p1.add(tf2c);
		p1.add(tf3);
		p1.add(tf3p);
		p1.add(tf3c);
		p1.add(tf4);
		p1.add(tf4p);
		p1.add(tf4c);
		p1.add(tf5);
		p1.add(tf5p);
		p1.add(tf5c);
		p1.add(tf6);
		p1.add(tf6p);
		p1.add(tf6c);
		p1.add(tf7);
		p1.add(tf7p);
		p1.add(tf7c);
		p1.add(tf8);
		p1.add(tf8p);
		p1.add(tf8c);
		
		p2.setLayout(new GridLayout(2, 3,0,0));
		p2.setBounds(10, 310, 300, 65);
		p2.add(fiveCount);
		p2.add(new JLabel());
		p2.add(oneCount);
		p2.add(tf_five);
		p2.add(new JLabel("�Ž��� ��", JLabel.CENTER));
		p2.add(tf_one);
		
		p3.setLayout(new FlowLayout());
		p3.setBounds(10, 390, 300, 100);
		p3.add(submit);
		p3.add(cancel);
		
		add(p1);
		add(p2);
		add(p3);
		
		setTitle("���Ǳ� ��ǰ �ʱ�ȭ");
		setBounds(500,200,320,460);
		setVisible(true);
	
		
	
	}

}
