package com.kosta.vending.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class MainView extends JFrame{
	
	JPanel productP, inputP, outputP;
	public JPanel p1, p2, p3, p4, p5, p6, p7, p8;
	public JLabel la1, la1_1, la2, la2_1, la3, la3_1, la4, la4_1, la5, la5_1, la6, la6_1, la7, la7_1, la8, la8_1;
	JLabel price, won;
	public JTextField tf;
	public JButton bill, coin5, coin1, moneyBack;
	

	public MainView() {
		productP = new JPanel();
		inputP = new JPanel();
		outputP = new JPanel();
		p1 = new JPanel();
		p2 = new JPanel();
		p3 = new JPanel();
		p4 = new JPanel();
		p5 = new JPanel();
		p6 = new JPanel();
		p7 = new JPanel();
		p8 = new JPanel();
		la1 = new JLabel("����", JLabel.CENTER);
		la1_1 = new JLabel("�����", JLabel.CENTER);
		la2 = new JLabel("����", JLabel.CENTER);
		la2_1 = new JLabel("�Ŷ��", JLabel.CENTER);
		la3 = new JLabel("����", JLabel.CENTER);
		la3_1 = new JLabel("�նѲ�", JLabel.CENTER);
		la4 = new JLabel("����", JLabel.CENTER);
		la4_1 = new JLabel("�ع�����", JLabel.CENTER);
		la5 = new JLabel("����", JLabel.CENTER);
		la5_1 = new JLabel("��ġ���", JLabel.CENTER);
		la6 = new JLabel("����", JLabel.CENTER);
		la6_1 = new JLabel("������", JLabel.CENTER);
		la7 = new JLabel("����", JLabel.CENTER);
		la7_1 = new JLabel("���ĸ�", JLabel.CENTER);
		la8 = new JLabel("����", JLabel.CENTER);
		la8_1 = new JLabel("��¡��«��", JLabel.CENTER);
		price = new JLabel("�ݾ�");
		won = new JLabel("��");
		tf = new JTextField("0",4);
		bill = new JButton("1000��");
		coin5 = new JButton("500��");
		coin1 = new JButton("100��");
		moneyBack = new JButton("��ȯ");
	
		//��ü����
		la1.setEnabled(false);
		la2.setEnabled(false);
		la3.setEnabled(false);
		la4.setEnabled(false);
		la5.setEnabled(false);
		la6.setEnabled(false);
		la7.setEnabled(false);
		la8.setEnabled(false);
		
		setLayout(null);
		productP.setLayout(new GridLayout(2, 4,5,5));
		p1.setLayout(new BorderLayout());
		p2.setLayout(new BorderLayout());
		p3.setLayout(new BorderLayout());
		p4.setLayout(new BorderLayout());
		p5.setLayout(new BorderLayout());
		p6.setLayout(new BorderLayout());
		p7.setLayout(new BorderLayout());
		p8.setLayout(new BorderLayout());
		inputP.setLayout(new FlowLayout());
		outputP.setLayout(new FlowLayout());
		
		
		//�Ӽ�����
		p1.add(la1, "Center");
		p1.add(la1_1, "South");
		p1.setBackground(Color.gray);
		p2.add(la2, "Center");
		p2.add(la2_1, "South");
		p2.setBackground(Color.gray);
		p3.add(la3, "Center");
		p3.add(la3_1, "South");
		p3.setBackground(Color.gray);
		p4.add(la4, "Center");
		p4.add(la4_1, "South");
		p4.setBackground(Color.gray);
		p5.add(la5, "Center");
		p5.add(la5_1, "South");
		p5.setBackground(Color.gray);
		p6.add(la6, "Center");
		p6.add(la6_1, "South");
		p6.setBackground(Color.gray);
		p7.add(la7, "Center");
		p7.add(la7_1, "South");
		p7.setBackground(Color.gray);
		p8.add(la8, "Center");
		p8.add(la8_1, "South");
		p8.setBackground(Color.gray);
		productP.add(p1);
		productP.add(p2);
		productP.add(p3);
		productP.add(p4);
		productP.add(p5);
		productP.add(p6);
		productP.add(p7);
		productP.add(p8);
		productP.setBounds(10,10,630,300);
		
		tf.setEditable(false);
		inputP.add(price);
		inputP.add(tf);
		inputP.add(won);
		inputP.add(bill);
		inputP.add(coin5);
		inputP.add(coin1);
		inputP.add(moneyBack);
		inputP.setBounds(10,350,630,50);
		
		add(productP);
		add(inputP);
		//������
		
		setBounds(400,20,650,850);
		setVisible(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	
	}
	
	
}
